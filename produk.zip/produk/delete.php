<?php
header('Content-Type: application/json'); // agar Flutter bisa parsing JSON

$koneksi = new mysqli("localhost", "fore6986_hafiizh_uas", "hafiizh123", "fore6986_hafiizh_uas");

if ($koneksi->connect_error) {
    echo json_encode(['message' => 'Koneksi gagal: ' . $koneksi->connect_error]);
    exit;
}

if (!isset($_POST['id'])) {
    echo json_encode(['message' => 'ID tidak ditemukan']);
    exit;
}

$id = intval($_POST['id']);

$stmt = $koneksi->prepare("DELETE FROM produk WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo json_encode(['message' => 'Produk berhasil dihapus']);
} else {
    echo json_encode(['message' => 'Gagal menghapus produk']);
}

$stmt->close();
$koneksi->close();
