<?php
$koneksi = new mysqli("localhost", "fore6986_hafiizh_uas", "hafiizh123", "fore6986_hafiizh_uas");

// Cegah SQL Injection (gunakan prepared statement di produksi)
$id = intval($_GET['id']); // konversi ke integer agar aman

$data = mysqli_query($koneksi, "SELECT * FROM produk WHERE id = $id");
$data = mysqli_fetch_array($data, MYSQLI_ASSOC);

// Tambahkan header agar hasil dianggap JSON
header('Content-Type: application/json');

// Kirimkan data sebagai JSON
echo json_encode($data);
