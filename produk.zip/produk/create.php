<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

$targetDir = "uploads/";
$uploadedFile = '';

// Cek apakah ada file gambar yang diupload
if (isset($_FILES["gambar"]) && $_FILES["gambar"]["error"] == 0) {
    $filename = basename($_FILES["gambar"]["name"]);
    $targetFilePath = $targetDir . $filename;

    if (move_uploaded_file($_FILES["gambar"]["tmp_name"], $targetFilePath)) {
        $uploadedFile = $targetFilePath;
    } else {
        echo json_encode(['message' => 'Upload gambar gagal']);
        exit;
    }
}
// Jika tidak ada file diupload, cek apakah nama file dikirim lewat POST
elseif (isset($_POST["gambar"]) && !empty($_POST["gambar"])) {
    $uploadedFile = $_POST["gambar"];
} 
// Kalau dua-duanya tidak ada
else {
    echo json_encode(['message' => 'Tidak ada gambar dikirim']);
    exit;
}

// Ambil data teks lain
$nama = $_POST['nama'] ?? '';
$kategori = $_POST['kategori'] ?? '';
$harga = $_POST['harga'] ?? '';
$stok = $_POST['stok'] ?? '';
$asal_daerah = $_POST['asal_daerah'] ?? '';
$deskripsi = $_POST['deskripsi'] ?? '';
$cerita_budaya = $_POST['cerita_budaya'] ?? '';

// Validasi data wajib
if (empty($nama) || empty($kategori) || empty($harga)) {
    echo json_encode(['message' => 'Data tidak lengkap']);
    exit;
}

$koneksi = new mysqli("localhost", "fore6986_hafiizh_uas", "hafiizh123", "fore6986_hafiizh_uas");

$query = "INSERT INTO produk (nama, kategori, harga, stok, gambar, asal_daerah, deskripsi, cerita_budaya) 
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $koneksi->prepare($query);
$stmt->bind_param("ssssssss", $nama, $kategori, $harga, $stok, $uploadedFile, $asal_daerah, $deskripsi, $cerita_budaya);

if ($stmt->execute()) {
    echo json_encode(['message' => 'Produk berhasil ditambahkan']);
} else {
    echo json_encode(['message' => 'Gagal menyimpan ke database']);
}

$stmt->close();
$koneksi->close();
?>
