<?php
header('Content-Type: application/json');

$koneksi = new mysqli("localhost", "fore6986_hafiizh_uas", "hafiizh123", "fore6986_hafiizh_uas");

// Ambil data dari POST
$id             = $_POST['id'];
$nama           = $_POST['nama'];
$kategori       = $_POST['kategori'];
$harga          = $_POST['harga'];
$stok           = $_POST['stok'];
$asal_daerah    = $_POST['asal_daerah'];
$deskripsi      = $_POST['deskripsi'];
$cerita_budaya  = $_POST['cerita_budaya'];

// Validasi dasar
if (!$id || !$nama) {
    http_response_code(400);
    echo json_encode(['message' => 'ID dan Nama wajib diisi']);
    exit;
}

// Handle gambar jika ada
$gambar = null;
if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == 0) {
    $targetDir = "uploads/";
    $filename = basename($_FILES["gambar"]["name"]);
    $targetFilePath = $targetDir . $filename;

    if (move_uploaded_file($_FILES["gambar"]["tmp_name"], $targetFilePath)) {
        $gambar = $targetFilePath;
    } else {
        echo json_encode(['success' => false, 'message' => 'Upload gambar gagal']);
        exit;
    }
}

// Buat query update
$query = "UPDATE produk SET 
    nama = '$nama',
    kategori = '$kategori',
    harga = '$harga',
    stok = '$stok',
    asal_daerah = '$asal_daerah',
    deskripsi = '$deskripsi',
    cerita_budaya = '$cerita_budaya'";

if ($gambar) {
    $query .= ", gambar = '$gambar'";
}

$query .= " WHERE id = '$id'";

$result = mysqli_query($koneksi, $query);

if ($result) {
    echo json_encode(['success' => true, 'message' => 'Produk berhasil diperbarui']);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal update', 'error' => mysqli_error($koneksi)]);
}
?>
