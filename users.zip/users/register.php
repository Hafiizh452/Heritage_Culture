<?php

header('Content-Type: application/json'); // ✅ Tambahkan header agar respons dikenali sebagai JSON

$koneksi = new mysqli("localhost", "fore6986_hafiizh_uas", "hafiizh123", "fore6986_hafiizh_uas");

// Cek koneksi
if ($koneksi->connect_error) {
    echo json_encode([
        'message' => 'Koneksi ke database gagal: ' . $koneksi->connect_error
    ]);
    exit();
}

// Ambil data dari request
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// Validasi sederhana
if (empty($username) || empty($password)) {
    echo json_encode([
        'message' => 'Username dan password tidak boleh kosong'
    ]);
    exit();
}

// Cek apakah username sudah terdaftar
$check = mysqli_query($koneksi, "SELECT * FROM users WHERE username = '$username'");

if (mysqli_num_rows($check) > 0) {
    echo json_encode([
        'message' => 'Username sudah digunakan'
    ]);
} else {
    $insert = mysqli_query($koneksi, "INSERT INTO users (username, password) VALUES ('$username', '$password')");
    if ($insert) {
        echo json_encode([
            'message' => 'Registrasi berhasil'
        ]);
    } else {
        echo json_encode([
            'message' => 'Registrasi gagal: ' . mysqli_error($koneksi)
        ]);
    }
}
?>
