<?php
header('Content-Type: application/json'); // ✅ Wajib untuk respons JSON

$koneksi = new mysqli("localhost", "fore6986_hafiizh_uas", "hafiizh123", "fore6986_hafiizh_uas");

// Cek koneksi
if ($koneksi->connect_error) {
    echo json_encode([
        'message' => 'Koneksi ke database gagal: ' . $koneksi->connect_error
    ]);
    exit();
}

// Ambil data dari POST dan validasi
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if (empty($username) || empty($password)) {
    echo json_encode([
        'message' => 'Username dan password wajib diisi'
    ]);
    exit();
}

// Cek ke database
$login = mysqli_query($koneksi, "SELECT * FROM users WHERE username = '$username' AND password = '$password'");

if ($login && mysqli_num_rows($login) > 0) {
    $data = mysqli_fetch_assoc($login);
    echo json_encode([
        'message' => 'Login berhasil',
        'user' => [
            'id' => $data['id'],
            'username' => $data['username']
        ]
    ]);
} else {
    echo json_encode([
        'message' => 'Username atau password salah'
    ]);
}
?>
