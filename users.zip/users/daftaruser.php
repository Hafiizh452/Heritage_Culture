<?php
header('Content-Type: application/json');

// Matikan error agar tidak tampil ke client
error_reporting(0);
ini_set('display_errors', 0);

$koneksi = new mysqli("localhost", "fore6986_hafiizh_uas", "hafiizh123", "fore6986_hafiizh_uas");

if ($koneksi->connect_error) {
    echo json_encode(['message' => 'Koneksi gagal: ' . $koneksi->connect_error]);
    exit;
}

// PERBAIKAN DI SINI
$query = "SELECT id, username FROM users";
$result = $koneksi->query($query);

if (!$result) {
    echo json_encode(['message' => 'Query gagal: ' . $koneksi->error]);
    exit;
}

$users = [];

while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}

echo json_encode($users);

$result->free();
$koneksi->close();
?>
