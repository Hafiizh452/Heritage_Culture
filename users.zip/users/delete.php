<?php
header('Content-Type: application/json');

$koneksi = new mysqli("localhost", "fore6986_hafiizh_uas", "hafiizh123", "fore6986_hafiizh_uas");

if ($koneksi->connect_error) {
    echo json_encode(['message' => 'Koneksi gagal: ' . $koneksi->connect_error]);
    exit;
}

// Ambil ID dari POST
$id = $_POST['id'] ?? '';

if (empty($id)) {
    echo json_encode(['message' => 'ID wajib dikirim']);
    exit;
}

// Gunakan prepared statement untuk keamanan
$stmt = $koneksi->prepare("DELETE FROM users WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo json_encode(['message' => 'User berhasil dihapus']);
} else {
    echo json_encode(['message' => 'Gagal menghapus user']);
}

$stmt->close();
$koneksi->close();
?>
