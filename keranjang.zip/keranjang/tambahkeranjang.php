<?php
header('Content-Type: application/json');

// Koneksi ke database
$koneksi = new mysqli("localhost", "fore6986_hafiizh_uas", "hafiizh123", "fore6986_hafiizh_uas");

if ($koneksi->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Koneksi gagal: ' . $koneksi->connect_error]);
    exit;
}

// Ambil data dari POST
$username = $_POST['username'] ?? '';
$produk_id = $_POST['produk_id'] ?? '';
$jumlah = isset($_POST['jumlah']) ? (int)$_POST['jumlah'] : 1;

// Validasi input
if (empty($username) || empty($produk_id)) {
    echo json_encode(['status' => 'error', 'message' => 'Username dan produk_id wajib dikirim']);
    exit;
}

// Cek apakah produk sudah ada di keranjang user
$query = $koneksi->prepare("SELECT id, jumlah FROM keranjang WHERE username = ? AND produk_id = ?");
$query->bind_param("si", $username, $produk_id);
$query->execute();
$result = $query->get_result();

if ($result->num_rows > 0) {
    // Produk sudah ada, update jumlah
    $row = $result->fetch_assoc();
    $id_keranjang = $row['id'];
    $jumlah_baru = $row['jumlah'] + $jumlah;

    $update = $koneksi->prepare("UPDATE keranjang SET jumlah = ? WHERE id = ?");
    $update->bind_param("ii", $jumlah_baru, $id_keranjang);
    $success = $update->execute();
    $update->close();
} else {
    // Produk belum ada, insert baru
    $insert = $koneksi->prepare("INSERT INTO keranjang (username, produk_id, jumlah) VALUES (?, ?, ?)");
    $insert->bind_param("sii", $username, $produk_id, $jumlah);
    $success = $insert->execute();
    $insert->close();
}

$query->close();
$koneksi->close();

// Kirim response
if ($success) {
    echo json_encode(['status' => 'success', 'message' => 'Produk berhasil ditambahkan ke keranjang']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Gagal menambahkan produk ke keranjang']);
}
