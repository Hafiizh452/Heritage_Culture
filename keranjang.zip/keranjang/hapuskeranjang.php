<?php
header('Content-Type: application/json');

// Koneksi database
$koneksi = new mysqli("localhost", "fore6986_hafiizh_uas", "hafiizh123", "fore6986_hafiizh_uas");

if ($koneksi->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Koneksi gagal: ' . $koneksi->connect_error]);
    exit;
}

$id = $_POST['keranjang_id'] ?? '';

if (empty($id)) {
    echo json_encode(['status' => 'error', 'message' => 'keranjang_id wajib dikirim']);
    exit;
}

$stmt = $koneksi->prepare("DELETE FROM keranjang WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Produk berhasil dihapus dari keranjang']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Gagal menghapus produk']);
}

$stmt->close();
$koneksi->close();
