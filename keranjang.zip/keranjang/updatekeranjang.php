<?php
header('Content-Type: application/json');

// Koneksi database
$koneksi = new mysqli("localhost", "fore6986_hafiizh_uas", "hafiizh123", "fore6986_hafiizh_uas");

if ($koneksi->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Koneksi gagal: ' . $koneksi->connect_error]);
    exit;
}

$id = $_POST['keranjang_id'] ?? '';
$jumlah = $_POST['jumlah'] ?? '';

if (empty($id) || $jumlah === '') {
    echo json_encode(['status' => 'error', 'message' => 'keranjang_id dan jumlah wajib dikirim']);
    exit;
}

$stmt = $koneksi->prepare("UPDATE keranjang SET jumlah = ? WHERE id = ?");
$stmt->bind_param("ii", $jumlah, $id);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Jumlah berhasil diperbarui']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Gagal update jumlah']);
}

$stmt->close();
$koneksi->close();
