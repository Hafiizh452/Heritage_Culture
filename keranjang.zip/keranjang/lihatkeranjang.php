<?php
header('Content-Type: application/json');

// Koneksi ke database
$koneksi = new mysqli("localhost", "fore6986_hafiizh_uas", "hafiizh123", "fore6986_hafiizh_uas");

if ($koneksi->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Koneksi gagal: ' . $koneksi->connect_error]);
    exit;
}

// Ambil username dari POST
$username = $_POST['username'] ?? '';

if (empty($username)) {
    echo json_encode(['status' => 'error', 'message' => 'Username wajib dikirim']);
    exit;
}

// Query JOIN keranjang + produk
$sql = "
    SELECT 
        keranjang.id AS keranjang_id,
        produk.id AS produk_id,
        produk.nama,
        produk.harga,
        produk.gambar,
        keranjang.jumlah,
        (produk.harga * keranjang.jumlah) AS total_harga
    FROM keranjang
    JOIN produk ON keranjang.produk_id = produk.id
    WHERE keranjang.username = ?
";

$stmt = $koneksi->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

$keranjang = [];
while ($row = $result->fetch_assoc()) {
    // Pastikan URL gambar absolut dan tidak double path
    if (!empty($row['gambar']) && substr($row['gambar'], 0, 4) !== 'http') {
        // Ambil hanya nama file, buang path seperti 'uploads/'
        $filename = basename($row['gambar']);
        $row['gambar'] = 'https://alpatt.fortunis11.com/produk/uploads/' . $filename;
    }
    $keranjang[] = $row;
}

echo json_encode([
    "status" => "success",
    "data" => $keranjang
]);

$stmt->close();
$koneksi->close();
